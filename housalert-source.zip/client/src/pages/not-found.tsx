import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { useTranslation } from "@/i18n";

export default function NotFound() {
  const { t } = useTranslation();
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-ha-bg">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="pt-6">
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-ha-primary" />
            <h1 className="text-2xl font-medium text-ha-text">{t("notFound.title")}</h1>
          </div>

          <p className="mt-4 text-sm text-ha-text">
            {t("notFound.desc")}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
