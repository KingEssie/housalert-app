import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[--ha-btn-radius] text-[16px] font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/20 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 transition-colors",
  {
    variants: {
      variant: {
        default:
          "bg-ha-primary hover:bg-ha-primary-hover text-white border-0",
        destructive:
          "bg-destructive text-destructive-foreground border border-destructive-border",
        outline:
          "border-2 border-ha-primary bg-white text-ha-primary hover:bg-ha-primary/5",
        secondary: "border border-ha-card-border bg-white text-ha-text hover:bg-ha-surface",
        ghost: "border border-transparent hover:bg-ha-surface",
        banner: "bg-white text-ha-text hover:bg-ha-surface border-0 font-medium",
      },
      size: {
        default: "min-h-[48px] px-7 py-3",
        sm: "min-h-8 rounded-[--ha-btn-radius] px-4 text-xs",
        lg: "min-h-[48px] rounded-[--ha-btn-radius] px-8",
        icon: "h-9 w-9",
        compact: "min-h-[44px] px-5 py-2 text-[14px]",
        save: "min-h-[48px] w-[180px] px-6",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }
